package ar.tp2.poo.dylan.tp2dylanvega.java.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Comparator;

import ar.tp2.poo.dylan.tp2dylanvega.java.consesionaria.Auto;
import ar.tp2.poo.dylan.tp2dylanvega.java.consesionaria.Moto;
import ar.tp2.poo.dylan.tp2dylanvega.java.consesionaria.Vehiculo;

public class TestConsesionaria {
    public static void main(String[] args) {
        Auto auto1 = new Auto("Peugeot", "206", 4, 200000);
        Moto moto1 = new Moto("Honda", "Titan", 125, 60000);
        Auto auto2 = new Auto("Peugeot", "208", 5, 250000);
        Moto moto2 = new Moto("Yamaha", "YBR", 160, 80500.5);

    List<Vehiculo> vehiculos = new ArrayList<>();

    vehiculos.add(auto1);
    vehiculos.add(moto1);
    vehiculos.add(auto2);
    vehiculos.add(moto2);

    vehiculos.forEach(System.out::println);

    System.out.println("\n==================================\n");

    Vehiculo vehiculoMasCaro = vehiculos
                                    .stream()
                                    .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                                    .get();
    Vehiculo vehiculoMasBarato = vehiculos
                                    .stream()
                                    .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                                    .get();
    System.out.println("Vehiculo mas caro: " + vehiculoMasCaro.getMarca() + " " + vehiculoMasCaro.getModelo() );
    System.out.println("Vehiculo mas barato: " + vehiculoMasBarato.getMarca() + " " + vehiculoMasBarato.getModelo());
    System.out.print("Vehiculo que contiene una 'Y': " );
    vehiculos
        .stream()
        .filter(v->v.getMarca().toLowerCase().contains("y"))
        .forEach(f->System.out.println(f.getMarca() + " " + f.getModelo() + " " + f.getPrecio()));

    System.out.println("\n==================================\n");

    System.out.println("Vehiculos ordenados por precio de Mayor a Menor: ");
    vehiculos
        .stream()
        .sorted(Comparator.comparing(Vehiculo::getPrecio).reversed())
        .forEach(f->System.out.println(f.getMarca() + " " + f.getModelo()));
                                                                
    System.out.println("\n==================================\n");
    
    System.out.println("Vehiculos ordenados por orden natural (marca, modelo, precio):");

    Collections.sort(vehiculos);

    vehiculos.forEach(System.out::println);

    }
}
