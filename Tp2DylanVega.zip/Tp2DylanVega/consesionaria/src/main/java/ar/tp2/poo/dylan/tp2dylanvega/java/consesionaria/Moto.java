package ar.tp2.poo.dylan.tp2dylanvega.java.consesionaria;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter


public class Moto extends Vehiculo {
    int volumenTotal;

    public Moto(String marca, String modelo, int volumenTotal, double precio) {
        super(marca, modelo,precio);
        this.volumenTotal = volumenTotal;
    }

    @Override
    public String toString() {
        return "Marca: "+ marca + " // Modelo: " + modelo + " // Cilindrada: "+ volumenTotal + "c // Precio: $"+ precio;
    }
}
