package ar.tp2.poo.dylan.tp2dylanvega.java.consesionaria;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter


public class Auto extends Vehiculo{
    int cantidadDePuertas;

    public Auto(String marca, String modelo, int cantidadDePuertas, double precio) {
        super(marca, modelo,precio);
        this.cantidadDePuertas = cantidadDePuertas;
    }

    @Override
    public String toString() {
        return "Marca: "+ marca + " // Modelo: " + modelo + " // Puertas: "+ cantidadDePuertas + " // Precio: $"+ precio;
    }
    
}
