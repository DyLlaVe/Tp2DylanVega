package ar.tp2.poo.dylan.tp2dylanvega.java.consesionaria;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@Getter
@AllArgsConstructor
@EqualsAndHashCode

public abstract class Vehiculo implements Comparable<Vehiculo>{
    String marca;
    String modelo;
    double precio;
    
    @Override
    public int compareTo(Vehiculo vehiculo) {
        String thisVehiculo = this.getMarca() + "," + this.getModelo() + "," + this.getPrecio();
        String vehiculoOtro = vehiculo.getMarca() + "," + vehiculo.getModelo() + "," + vehiculo.getPrecio();
        return thisVehiculo.compareTo(vehiculoOtro);
    }

    
}
