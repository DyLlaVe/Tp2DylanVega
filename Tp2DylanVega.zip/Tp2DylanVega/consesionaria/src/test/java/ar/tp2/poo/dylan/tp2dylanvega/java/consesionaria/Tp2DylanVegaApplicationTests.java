package ar.tp2.poo.dylan.tp2dylanvega.java.consesionaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tp2DylanVegaApplicationTests {

	@Test
	void contextLoads() {
	}

}
